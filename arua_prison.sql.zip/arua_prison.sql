-- phpMyAdmin SQL Dump
-- version 2.10.1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Dec 14, 2015 at 10:58 AM
-- Server version: 5.0.41
-- PHP Version: 5.2.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `arua_prison`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `contact`
-- 

CREATE TABLE `contact` (
  `Id` int(10) NOT NULL auto_increment,
  `name` varchar(20) NOT NULL,
  `email` varchar(13) NOT NULL,
  `phone` varchar(12) NOT NULL,
  `subject` varchar(16) NOT NULL,
  `message` varchar(17) NOT NULL,
  PRIMARY KEY  (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

-- 
-- Dumping data for table `contact`
-- 

INSERT INTO `contact` (`Id`, `name`, `email`, `phone`, `subject`, `message`) VALUES 
(1, 'duku', 'duku@gmail.co', '07787877', 'delay in reply', 'good work'),
(2, 'baraka', 'baraka.martin', '0792215744', 'nice', 'i love your work'),
(3, 'kevin', 'kevingmail.co', '07857854', 'good', 'good');

-- --------------------------------------------------------

-- 
-- Table structure for table `reporting`
-- 

CREATE TABLE `reporting` (
  `id` int(11) NOT NULL auto_increment,
  `fname` varchar(25) NOT NULL,
  `phone` int(13) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `adress` varchar(30) NOT NULL,
  `date_incid` varchar(35) NOT NULL,
  `offender` varchar(30) NOT NULL,
  `type_incid` varchar(50) NOT NULL,
  `staf_member` varchar(50) NOT NULL,
  `inst_crime` varchar(35) NOT NULL,
  `descript_crime` varchar(40) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

-- 
-- Dumping data for table `reporting`
-- 

INSERT INTO `reporting` (`id`, `fname`, `phone`, `gender`, `email`, `adress`, `date_incid`, `offender`, `type_incid`, `staf_member`, `inst_crime`, `descript_crime`) VALUES 
(1, 'baraka', 7787877, 'male', 'baraka.m@gmail.com', 'arua', '12/12/2015', 'mike and jimmy', 'theft', 'jacky', 'rubaga', 'dangerous'),
(2, 'manasseh', 7887767, 'male', 'baraka@gmail.com', 'rubaga', '12/12/2015', 'jackyy', 'stealing', 'mike', 'arua prison', 'horrible'),
(3, 'bdsafds', 777484334, 'dfg', 'baraka@gmail.com', 'gdsf', '12/12/2015', 'gfdsg', 'tyfag', 'fsg', 'fdg', 'fgbgf'),
(4, 'baraka', 0, 'male', 'marial@gmail.com', 'rubaga', '12/12/2015', 'baraka', 'roberry', 'okot', 'street', 'bad'),
(5, 'mabok', 79226744, 'male', 'mabok@gmail.com', 'rubaga', '12/12/2015', 'micheal', 'theft', 'mike', 'luzira zone', 'harmful');

-- --------------------------------------------------------

-- 
-- Table structure for table `transfer`
-- 

CREATE TABLE `transfer` (
  `id` int(11) NOT NULL auto_increment,
  `fname` varchar(25) NOT NULL,
  `lname` varchar(25) NOT NULL,
  `status` varchar(20) NOT NULL,
  `inst_adress` varchar(20) NOT NULL,
  `nsupervisor` varchar(30) NOT NULL,
  `ofadress` varchar(35) NOT NULL,
  `outcharge` varchar(30) NOT NULL,
  `sex` text NOT NULL,
  `language` text NOT NULL,
  `pre_conviction` varchar(35) NOT NULL,
  `hist_violence` varchar(40) NOT NULL,
  `date_transfer` varchar(10) NOT NULL,
  `medical` varchar(45) NOT NULL,
  `ofname` varchar(25) NOT NULL,
  `place_sentence` mediumtext NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- 
-- Dumping data for table `transfer`
-- 

INSERT INTO `transfer` (`id`, `fname`, `lname`, `status`, `inst_adress`, `nsupervisor`, `ofadress`, `outcharge`, `sex`, `language`, `pre_conviction`, `hist_violence`, `date_transfer`, `medical`, `ofname`, `place_sentence`) VALUES 
(1, 'baraka', 'martins', 'married', 'arua area', 'kevin', 'hassan', 'theft', 'Male', 'English', 'No', 'Minor', '23/2/2014', 'malaria', 'jancier', 'arua'),
(2, 'solomon', 'duku', 'single', 'oli', 'baraka', 'rubaga', 'assault', 'Male', 'French', 'Yes', 'Senior', '12/3/2013', 'none', 'janvier', 'arua prison');
