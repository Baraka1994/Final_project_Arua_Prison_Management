-- phpMyAdmin SQL Dump
-- version 2.10.1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Dec 14, 2015 at 10:58 AM
-- Server version: 5.0.41
-- PHP Version: 5.2.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `slau_registration`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `users`
-- 

CREATE TABLE `users` (
  `user_id` int(5) NOT NULL auto_increment,
  `username` varchar(25) NOT NULL,
  `email` varchar(35) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY  (`user_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

-- 
-- Dumping data for table `users`
-- 

INSERT INTO `users` (`user_id`, `username`, `email`, `password`) VALUES 
(1, 'ahmed ', 'ahmed@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055'),
(2, 'baraka', 'baraka@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b'),
(3, 'baraka', 'baraka.martin65@gmail.com', '3f1c5efb90eaf72e935598b23e701220');
